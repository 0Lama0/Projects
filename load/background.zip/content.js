setInterval(function() {
    location.reload();
}, 7000);